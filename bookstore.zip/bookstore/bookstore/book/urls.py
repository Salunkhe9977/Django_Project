from django.contrib import admin
from django.urls import path,include
from . import views
from bookstore.settings import DEBUG, STATIC_URL, MEDIA_URL, MEDIA_ROOT
from django.conf.urls.static import static



urlpatterns = [
    path('', views.home, name='home'),
    path('upload',views.upload,name='upload'),
    path('update/<int:book_id>',views.update_book),
    path('delete/<int:book_id>',views.delete_book),

]



if DEBUG:
    urlpatterns += static(MEDIA_URL, document_root = MEDIA_ROOT)
from django.db import models

# Create your models here.
class Employee(models.Model):
    eid=models.CharField(max_length=40)
    name=models.CharField(max_length=100)
    email=models.EmailField()
    contact=models.CharField(max_length=100)
    
    class Meta:
        db_table="employee"

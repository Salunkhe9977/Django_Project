from django.shortcuts import render
from employee.models import Employee
from employee.form import EmployeeForm

# Create your views here.
def home(request):
    if(request.method=="POST"):
        form=EmployeeForm(request.POST)
        
        if(form.is_valid()):
            try:
                form.save()
                return HttpResponseRedirect("/show")
            except:
                pass
        
    else:
        form=EmployeeForm()
        return render(request,'index.html',{'form':form})



#show list of the all employees added by user
def show(request):
    #fethching all employees records 
    #internally django performing select * from employee >> rows-column format >> objects 
    employees = Employee.objects.all() 
    
    #populationg data to show.html
    return render(request,"show.html",{'employees':employees})  
    
#select a particular employee by its id and display the details on screen for updation
def edit(request, id):
    #fetch single record select from employee where id=<id>;
    employee = Employee.objects.get(id=id)
    #displaying that employee record 
    return render(request,'edit.html', {'employee':employee})  
 
#Fill the edit.html form data with updated values  
def update(request, id):  
	    employee = Employee.objects.get(id=id)  
	    form = EmployeeForm(request.POST,instance = employee)  
	    if form.is_valid():  
	        form.save()  
	        return renderHttpResponse("/show")  
	    return render(request, 'edit.html', {'employee': employee})  

#fetch the record to delete , delete from employee where id=1
def destroy(request, id):  
	    employee = Employee.objects.get(id=id)  
	    employee.delete()  
	    return redirect("/show")  




    



    